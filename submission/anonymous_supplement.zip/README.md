# Supplementary Code

Anonymous supplementary material for "Truth as a Compression Artifact in Language Model Training".

## Contents

- `training/`: MLX training and evaluation code.
- `training_torch/`: PyTorch training and paired-evaluation code.
- `data/`: corpus and paired-test generators.
- `analysis/`: scripts used for plots and summary analyses.
- `scripts/reproduce_minimal.sh`: minimal reproduction for the central random-vs-coherent contrast.
- `results/`: lightweight JSON/CSV summaries and paper figures only; model weights and large generated corpora are intentionally omitted.

## Minimal Reproduction

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements_minimal.txt

# For CUDA reproduction, install PyTorch matching the local CUDA version.
bash scripts/reproduce_minimal.sh
```

The script trains two tiny PyTorch models, one with random errors and one with coherent errors, then runs paired evaluation. The expected pattern is random-error accuracy above chance and coherent-error accuracy near chance.

## Notes

Generated corpora can be recreated with the scripts in `data/`. Large model checkpoints are not included to keep the supplementary archive small and reviewable.
